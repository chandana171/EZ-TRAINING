#even or odd
n=13
if n&1 == 0:
    print("even")
else:
    print("odd")